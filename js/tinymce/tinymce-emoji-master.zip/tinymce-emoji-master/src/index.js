import plugin from './plugin';

tinymce.PluginManager.add('tinymceEmoji', plugin);
